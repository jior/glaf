package com.glaf.shiro;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.glaf.core.web.callback.LoginCallback;

public class ShiroLoginCallback implements LoginCallback {

	public void afterLogin(String actorId, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			ShiroSecurity.login(actorId, "pwd");
		} catch (Throwable ex) {
			ex.printStackTrace();
		}
	}

}
