 
create table ${tableName} (
        ID_ NVARCHAR2(50),
        TASKID_ NVARCHAR2(50),
        MAILTO_ NVARCHAR2(100),
        ACCOUNTID_ NVARCHAR2(50),
        SENDDATE_ TIMESTAMP(6),
        SENDSTATUS_  INTEGER,
        RETRYTIMES_  INTEGER,
        RECEIVEIP_ NVARCHAR2(50),
        RECEIVEDATE_ TIMESTAMP(6),
        RECEIVESTATUS_  INTEGER,
        BROWSER_ NVARCHAR2(50),
        CONTENTTYPE_ NVARCHAR2(500),
        CLIENTOS_ NVARCHAR2(50),        
	    LASTMODIFIED_ NUMBER(19,0),
        primary key (ID_)
) ;

