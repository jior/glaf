/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.glaf.core.service.impl;

import java.util.Collection;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glaf.core.base.DataModelEntity;
import com.glaf.core.dao.EntityDAO;
import com.glaf.core.id.IdGenerator;
import com.glaf.core.mapper.ColumnDefinitionMapper;
import com.glaf.core.mapper.IdMapper;
import com.glaf.core.mapper.TableDataMapper;
import com.glaf.core.mapper.TablePageMapper;
import com.glaf.core.query.DataModelQuery;
import com.glaf.core.service.DataModelService;
import com.glaf.core.service.ITableDefinitionService;
import com.glaf.core.util.Paging;

@Service("dataModelService")
@Transactional
public class MxDataModelServiceImpl implements DataModelService {
	protected final static Log logger = LogFactory
			.getLog(MxDataModelServiceImpl.class);

	protected ColumnDefinitionMapper columnDefinitionMapper;

	protected EntityDAO entityDAO;

	protected IdGenerator idGenerator;

	protected IdMapper idMapper;

	protected SqlSession sqlSession;

	protected TableDataMapper tableDataMapper;

	protected ITableDefinitionService tableDefinitionService;

	protected TablePageMapper tablePageMapper;

	public MxDataModelServiceImpl() {

	}

	@Transactional
	public void deleteAll(String tableName, Collection<String> businessKeys) {

	}

	public DataModelEntity getDataModel(String tableName, Long id) {

		return null;
	}

	public DataModelEntity getDataModelByBusinessKey(String tableName,
			String businessKey) {

		return null;
	}

	public DataModelEntity getDataModelByProcessInstanceId(String tableName,
			String processInstanceId) {

		return null;
	}

	public int getDataModelCount(DataModelQuery query) {

		return 0;
	}

	public DataModelEntity getDataModelWithAll(String tableName, Long id) {

		return null;
	}

	public Paging getPageDataModels(DataModelQuery query) {

		return null;
	}

	@Transactional
	public void insert(DataModelEntity dataModelEntity) {

	}

	public List<DataModelEntity> list(DataModelQuery query) {

		return null;
	}

	public List<DataModelEntity> list(int pageNo, int pageSize,
			DataModelQuery query) {

		return null;
	}

	@Resource
	public void setColumnDefinitionMapper(
			ColumnDefinitionMapper columnDefinitionMapper) {
		this.columnDefinitionMapper = columnDefinitionMapper;
	}

	@Resource
	@Qualifier("myBatisEntityDAO")
	public void setEntityDAO(EntityDAO entityDAO) {
		this.entityDAO = entityDAO;
	}

	@Resource
	@Qualifier("myBatisDbIdGenerator")
	public void setIdGenerator(IdGenerator idGenerator) {
		this.idGenerator = idGenerator;
	}

	@Resource
	public void setIdMapper(IdMapper idMapper) {
		this.idMapper = idMapper;
	}

	@Resource
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	@Resource
	public void setTableDataMapper(TableDataMapper tableDataMapper) {
		this.tableDataMapper = tableDataMapper;
	}

	@Resource
	public void setTableDefinitionService(
			ITableDefinitionService tableDefinitionService) {
		this.tableDefinitionService = tableDefinitionService;
	}

	@Resource
	public void setTablePageMapper(TablePageMapper tablePageMapper) {
		this.tablePageMapper = tablePageMapper;
	}

	@Transactional
	public void update(DataModelEntity dataModelEntity) {

	}

}