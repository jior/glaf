package com.glaf.core.config;

import java.io.IOException;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

/**
 * ���԰��ղ�ͬ������ģʽ������Ӧ������
 * 
 */
public class MutilPropertyPlaceholderConfigurer extends
		PropertyPlaceholderConfigurer implements InitializingBean {

	protected static final Log LOG = LogFactory
			.getLog(MutilPropertyPlaceholderConfigurer.class);

	public static final String DEVELOPMENT = "DEV";

	public static final String PRODUCTION = "PRD";

	public static final String RUN_MODE = "run.mode";

	// �������е���������
	private Properties properties;

	@Override
	public void afterPropertiesSet() throws Exception {

	}

	/**
	 * @return the mode
	 */
	public String getMode() {
		return properties.getProperty(RUN_MODE);
	}

	/**
	 * ���Ŵ˷�������Ҫ��ҵ��
	 * 
	 * @param key
	 * @return
	 */
	public String getProperty(String key) {
		return resolvePlaceholder(key, properties);
	}

	@Override
	protected Properties mergeProperties() throws IOException {
		Properties mergeProperties = super.mergeProperties();
		// ����·��ԭ����ȡ������Ч��properties
		this.properties = new Properties();
		// ��ȡ·�ɹ���,ϵͳ��������mode����
		String mode = System.getProperty(RUN_MODE);
		if (StringUtils.isEmpty(mode)) {
			String str = mergeProperties.getProperty(RUN_MODE);
			mode = str != null ? str : PRODUCTION;
		}
		LOG.info("####run mode:" + mode);
		properties.put(RUN_MODE, mode);
		String[] modes = mode.split(",");
		Set<Entry<Object, Object>> es = mergeProperties.entrySet();
		for (Entry<Object, Object> entry : es) {
			String key = (String) entry.getKey();
			int idx = key.lastIndexOf('_');
			String realKey = idx == -1 ? key : key.substring(0, idx);
			if (!properties.containsKey(realKey)) {
				Object value = null;
				for (String md : modes) {
					value = mergeProperties.get(realKey + "_" + md);
					if (value != null) {
						properties.put(realKey, value);
						break;
					}
				}
				if (value == null) {
					value = mergeProperties.get(realKey);
					if (value != null) {
						properties.put(realKey, value);
					}
				}
			}
		}
		logger.debug(properties);
		return properties;
	}
}
