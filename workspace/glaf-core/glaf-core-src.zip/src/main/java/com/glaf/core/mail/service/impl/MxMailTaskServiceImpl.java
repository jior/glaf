/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.glaf.core.mail.service.impl;

import java.util.*;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
 
import com.glaf.core.base.Scheduler;
import com.glaf.core.cache.CacheFactory;
import com.glaf.core.domain.SchedulerEntity;
import com.glaf.core.entity.EntityDAO;
import com.glaf.core.id.*;
import com.glaf.core.service.ISysSchedulerService;
import com.glaf.core.util.DateUtils;
 
import com.glaf.core.mail.domain.*;
import com.glaf.core.mail.mapper.*;
import com.glaf.core.mail.query.*;
import com.glaf.core.mail.service.*;

@Service("mailTaskService")
@Transactional(readOnly = true)
public class MxMailTaskServiceImpl implements IMailTaskService {
	protected final static Log logger = LogFactory
			.getLog(MxMailTaskServiceImpl.class);

	protected EntityDAO entityDAO;

	protected IdGenerator idGenerator;

	protected SqlSession sqlSession;

	protected MailItemMapper mailItemMapper;

	protected MailTaskMapper mailTaskMapper;

	protected MailAccountMapper mailAccountMapper;

	protected MailStorageMapper mailStorageMapper;

	protected MailTaskAccountMapper mailTaskAccountMapper;

	protected ISysSchedulerService sysSchedulerService;

	public MxMailTaskServiceImpl() {

	}

	public int count(MailTaskQuery query) {
		return mailTaskMapper.getMailTaskCount(query);
	}

	@Transactional
	public void deleteById(String id) {
		mailTaskMapper.deleteMailTaskById(id);
	}

	@Transactional
	public void deleteByIds(List<String> rowIds) {
		MailTaskQuery query = new MailTaskQuery();
		query.rowIds(rowIds);
		mailTaskMapper.deleteMailTasks(query);
	}

	public List<String> getAccountIds(String taskId) {
		List<String> list = new ArrayList<String>();
		List<MailTaskAccount> accounts = mailTaskAccountMapper
				.getMailTaskAccountsByTaskId(taskId);
		for (MailTaskAccount a : accounts) {
			list.add(a.getAccountId());
		}
		return list;
	}

	public MailTask getMailTask(String id) {
		 
		MailTask mailTask = mailTaskMapper.getMailTaskById(id);
		if (mailTask != null) {
			MailStorage stg = mailStorageMapper
					.getMailStorageById(mailTask.getStorageId());
			mailTask.setStorage(stg);
		}
	 
		return mailTask;
	}

	public MailTask getMailTaskWithAccounts(String taskId) {
		MailTask mailTask = mailTaskMapper.getMailTaskById(taskId);
		if (mailTask != null) {
			MailStorage stg = mailStorageMapper
					.getMailStorageById(mailTask.getStorageId());
			mailTask.setStorage(stg);
			List<MailAccount> accounts = mailAccountMapper
					.getMailAccountsByTaskId(taskId);
			mailTask.setAccounts(accounts);
		}
 
		return mailTask;
	}

	/**
	 * ���ݲ�ѯ������ȡ��¼����
	 * 
	 * @return
	 */
	public int getMailTaskCountByQueryCriteria(MailTaskQuery query) {
		return mailTaskMapper.getMailTaskCount(query);
	}

	/**
	 * ���ݲ�ѯ������ȡһҳ������
	 * 
	 * @return
	 */
	public List<MailTask> getMailTasksByQueryCriteria(int start, int pageSize,
			MailTaskQuery query) {
		RowBounds rowBounds = new RowBounds(start, pageSize);
		List<MailTask> rows = sqlSession.selectList("getMailTasks", query,
				rowBounds);
		return rows;
	}

	public List<MailTask> list(MailTaskQuery query) {
		List<MailTask> list = mailTaskMapper.getMailTasks(query);
		return list;
	}

	@Transactional
	public void save(MailTask mailTask) {
		if (StringUtils.isEmpty(mailTask.getId())) {
			mailTask.setId(idGenerator.getNextId());
			mailTask.setCreateDate(new Date());
			mailTaskMapper.insertMailTask(mailTask);
		} else {
			mailTaskMapper.updateMailTask(mailTask);
			String cacheKey = "mx_mail_act_" + mailTask.getId();
			CacheFactory.remove(cacheKey);
			cacheKey = "mx_mail_" + mailTask.getId();
			CacheFactory.remove(cacheKey);
		}

		String taskId = mailTask.getId();
		Scheduler scheduler = sysSchedulerService.getSchedulerByTaskId(taskId);
		boolean insert = false;
		if (scheduler == null) {
			scheduler = new SchedulerEntity();
			scheduler.setTaskId(taskId);
			scheduler.setCreateBy("system");
			scheduler.setCreateDate(new Date());
			insert = true;
		}
		scheduler.setTaskType("MX_MAIL_TASK");
		scheduler.setRepeatCount(-1);
		scheduler.setJobClass("com.glaf.core.mail.job.MailTaskJob");
		scheduler.setTaskName(taskId);
		scheduler.setTitle(mailTask.getSubject());
		scheduler.setStartDate(new Date());
		scheduler.setEndDate(new Date(System.currentTimeMillis()
				+ DateUtils.DAY * 3600));
		if (mailTask.getLocked() == 0) {
			scheduler.setLocked(0);
			scheduler.setAutoStartup(true);
			scheduler.setStartup(true);
		} else {
			scheduler.setLocked(1);
			scheduler.setAutoStartup(false);
			scheduler.setStartup(false);
		}
		if (insert) {
			sysSchedulerService.save(scheduler);
		} else {
			sysSchedulerService.update(scheduler);
		}
	}

	@Transactional
	public void saveAccounts(String taskId, List<String> accountIds) {
		mailTaskAccountMapper.deleteMailTaskAccountByTaskId(taskId);
		if (accountIds != null && !accountIds.isEmpty()) {
			for (String accountId : accountIds) {
				MailTaskAccount a = new MailTaskAccount();
				a.setAccountId(accountId);
				a.setTaskId(taskId);
				a.setId(idGenerator.getNextId());
				mailTaskAccountMapper.insertMailTaskAccount(a);
			}
		}
	}

	@Transactional
	public void saveMails(String taskId, List<String> mailAddresses) {
		if (mailAddresses != null && !mailAddresses.isEmpty()) {
			MailTask task = this.getMailTask(taskId);
			for (String mail : mailAddresses) {
				MailItem item = new MailItem();
				item.setId(idGenerator.getNextId());
				item.setMailTo(mail);
				item.setRetryTimes(0);
				item.setTaskId(taskId);
				item.setTableName(task.getStorage().getDataTable());
				item.setLastModified(System.currentTimeMillis());
				mailItemMapper.insertMailItem(item);
			}
		}
	}

	@javax.annotation.Resource
	@Qualifier("myBatisEntityDAO")
	public void setEntityDAO(EntityDAO entityDAO) {
		this.entityDAO = entityDAO;
	}

	@javax.annotation.Resource
	@Qualifier("myBatisDbIdGenerator")
	public void setIdGenerator(IdGenerator idGenerator) {
		this.idGenerator = idGenerator;
	}

	@javax.annotation.Resource
	public void setMailItemMapper(MailItemMapper mailItemMapper) {
		this.mailItemMapper = mailItemMapper;
	}

	@javax.annotation.Resource
	public void setMailAccountMapper(
			MailAccountMapper mailAccountMapper) {
		this.mailAccountMapper = mailAccountMapper;
	}

	@javax.annotation.Resource
	public void setMailTaskAccountMapper(
			MailTaskAccountMapper mailTaskAccountMapper) {
		this.mailTaskAccountMapper = mailTaskAccountMapper;
	}

	@javax.annotation.Resource
	public void setMailTaskMapper(MailTaskMapper mailTaskMapper) {
		this.mailTaskMapper = mailTaskMapper;
	}

	@javax.annotation.Resource
	public void setMailStorageMapper(
			MailStorageMapper mailStorageMapper) {
		this.mailStorageMapper = mailStorageMapper;
	}

	@javax.annotation.Resource
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	@javax.annotation.Resource
	public void setSysSchedulerService(ISysSchedulerService sysSchedulerService) {
		this.sysSchedulerService = sysSchedulerService;
	}

}