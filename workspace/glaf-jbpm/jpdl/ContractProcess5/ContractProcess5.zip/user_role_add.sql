insert into userrole (ID, roleid, userid, Rsysid, Ruserid) values ('1', 'R_ST1', 'admin', null, null);
insert into userrole (ID, roleid, userid, Rsysid, Ruserid) values ('2', 'R_ST2', 'admin', null, null);
insert into userrole (ID, roleid, userid, Rsysid, Ruserid) values ('3', 'R_ST3', 'admin', null, null);
insert into userrole (ID, roleid, userid, Rsysid, Ruserid) values ('4', 'R_ST4', 'admin', null, null);
insert into userrole (ID, roleid, userid, Rsysid, Ruserid) values ('5', 'R_ST5', 'admin', null, null);
insert into userrole (ID, roleid, userid, Rsysid, Ruserid) values ('6', 'R_ST', 'admin', null, null);