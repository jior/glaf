/*
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jpage.jbpm.renderer;

import java.io.BufferedReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.VelocityException;
import org.jpage.context.ApplicationContext;
import org.jpage.core.cache.CacheFactory;
import org.jpage.jbpm.el.DefaultExpressionEvaluator;
import org.jpage.jbpm.mail.JavaMailDigger;
import org.jpage.jbpm.model.MessageTemplate;

public class VelocityRenderer {
	private static final Log logger = LogFactory.getLog(VelocityRenderer.class);

	 

	protected static boolean isStartup = false;

	protected VelocityEngine velocityEngine;

	public VelocityEngine getVelocityEngine() {
		return velocityEngine;
	}

	public void setVelocityEngine(VelocityEngine velocityEngine) {
		this.velocityEngine = velocityEngine;
	}

	protected void startup() {
		if (isStartup) {
			return;
		}
		try {
			String path = ApplicationContext.getAppPath()
					+ "/resources/templates";
			path = org.jpage.util.FileTools.getJavaFileSystemPath(path);
			System.out.println("Velocity load path:" + path);
			Properties props = new Properties();
			props.setProperty("file.resource.loader.modificationCheckInterval",
					"3600");
			props.setProperty(Velocity.FILE_RESOURCE_LOADER_CACHE, "true");
			props.setProperty(Velocity.FILE_RESOURCE_LOADER_PATH, path);
			Velocity.init(props);
			isStartup = true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * ��Ⱦ
	 * 
	 * @param ctx
	 * @return
	 */
	public String render(RendererContext ctx) {

		if (!isStartup) {
			startup();
		}

		String content = null;
		Map variables = ctx.getVariables();
		MessageTemplate template = ctx.getMessageTemplate();
		if (variables != null) {
			variables.putAll(template.getVariables());
		} else {
			variables = template.getVariables();
		}

		String dataFile = template.getDataFile();
		String templateType = template.getTemplateType();
		String encoding = template.getEncoding();

		if (StringUtils.isBlank(encoding)) {
			encoding = "GBK";
		}

		StringWriter writer = new StringWriter();
		VelocityContext velocityContext = new VelocityContext(variables);

		try {
			if (templateType != null && template.getBytes() != null) {
				if ("eml".equalsIgnoreCase(templateType)) {
					String cacheKey = "cache_template_"
							+ template.getTemplateId();
					if (CacheFactory.get(cacheKey) != null) {
						content = (String) CacheFactory.get(cacheKey);
					} else {
						JavaMailDigger digger = new JavaMailDigger();
						content = digger.getContent(template.getBytes());
						CacheFactory.put(cacheKey, content);
					}
				} else if ("html".equalsIgnoreCase(template.getTemplateType())) {
					content = new String(template.getBytes());
				}
				if (content != null) {
					Reader reader = new BufferedReader(
							new StringReader(content));
					velocityEngine.evaluate(velocityContext, writer, null,
							reader);
					writer.flush();
					content = writer.toString();
				}
			} else if (dataFile != null) {
				velocityEngine.mergeTemplate(dataFile, encoding,
						velocityContext, writer);
				writer.flush();
				content = writer.toString();
			}
		} catch (VelocityException ex) {
			ex.printStackTrace();
			logger.error(ex);
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error(ex);
			throw new RuntimeException(ex);
		}

		content = (String) DefaultExpressionEvaluator.evaluate(content,
				variables);

		return content;
	}

}
