/*
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jpage.services.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jpage.core.query.paging.Page;
import org.jpage.persistence.Executor;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.ibatis.sqlmap.client.SqlMapExecutor;

public class SqlMapDAOImpl extends SqlMapClientDaoSupport implements SqlMapDAO {
	protected static final Log logger = LogFactory.getLog(SqlMapDAOImpl.class);

	public SqlMapDAOImpl() {

	}

	/**
	 * ����ִ�в���
	 * 
	 * @param rows
	 *            Executor����ļ���
	 * @see org.jpage.persistence.Executor
	 */
	public void executeBatch(final List rows) {
		getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
			public Object doInSqlMapClient(SqlMapExecutor executor)
					throws SQLException {
				executor.startBatch();
				Iterator iterator = rows.iterator();
				while (iterator.hasNext()) {
					Executor model = (Executor) iterator.next();
					String query = model.getQuery();
					query = query.trim().toLowerCase();
					List list = model.getListValues();
					if (list == null || list.size() == 0) {
						continue;
					}
					Iterator iter = list.iterator();
					while (iter.hasNext()) {
						Object obj = iter.next();
						if (query.startsWith("insert")) {
							executor.insert(model.getQuery(), obj);
						} else if (query.startsWith("update")) {
							executor.update(model.getQuery(), obj);
						} else if (query.startsWith("delete")) {
							executor.delete(model.getQuery(), obj);
						}
					}
				}
				executor.executeBatch();
				return null;
			}
		});
	}

	/**
	 * ����һ����¼
	 * 
	 * @param statementId
	 * @param obj
	 */
	public void insertObject(String statementId, Object parameterObject) {
		getSqlMapClientTemplate().insert(statementId, parameterObject);
	}

	/**
	 * �޸�һ����¼
	 * 
	 * @param statementId
	 * @param obj
	 */
	public void updateObject(String statementId, Object parameterObject) {
		getSqlMapClientTemplate().update(statementId, parameterObject);
	}

	/**
	 * ɾ��һ����¼
	 * 
	 * @param statementId
	 * @param obj
	 */
	public void deleteObject(String statementId, Object parameterObject) {
		getSqlMapClientTemplate().delete(statementId, parameterObject);
	}

	/**
	 * ���������¼
	 * 
	 * @param statementId
	 * @param rows
	 */
	public void insertAll(final String statementId, final List rows) {
		getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
			public Object doInSqlMapClient(SqlMapExecutor executor)
					throws SQLException {
				executor.startBatch();
				Iterator iterator = rows.iterator();
				while (iterator.hasNext()) {
					Object obj = iterator.next();
					executor.insert(statementId, obj);
				}
				executor.executeBatch();
				return null;
			}
		});
	}

	/**
	 * �޸Ķ�����¼
	 * 
	 * @param statementId
	 * @param rows
	 */
	public void updateAll(final String statementId, final List rows) {
		getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
			public Object doInSqlMapClient(SqlMapExecutor executor)
					throws SQLException {
				executor.startBatch();
				Iterator iterator = rows.iterator();
				while (iterator.hasNext()) {
					Object obj = iterator.next();
					executor.update(statementId, obj);
				}
				executor.executeBatch();
				return null;
			}
		});
	}

	/**
	 * ɾ��������¼
	 * 
	 * @param statementId
	 * @param rows
	 */
	public void deleteAll(final String statementId, final List rows) {
		getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
			public Object doInSqlMapClient(SqlMapExecutor executor)
					throws SQLException {
				executor.startBatch();
				Iterator iterator = rows.iterator();
				while (iterator.hasNext()) {
					Object obj = iterator.next();
					executor.delete(statementId, obj);
				}
				executor.executeBatch();
				return null;
			}
		});
	}

	public Object queryForObject(String statementId) {
		return getSqlMapClientTemplate().queryForObject(statementId, null);
	}

	public Object queryForObject(String statementId, Object parameterObject) {
		return getSqlMapClientTemplate().queryForObject(statementId,
				parameterObject);
	}

	public Object queryForObject(String statementId, Object parameterObject,
			Object resultObject) {
		return getSqlMapClientTemplate().queryForObject(statementId,
				parameterObject, resultObject);
	}

	public Map queryForMap(String statementId, Object parameterObject,
			String keyProperty) {
		return getSqlMapClientTemplate().queryForMap(statementId,
				parameterObject, keyProperty);
	}

	public Map queryForMap(String statementId, Object parameterObject,
			String keyProperty, String valueProperty) {
		return getSqlMapClientTemplate().queryForMap(statementId,
				parameterObject, keyProperty, valueProperty);
	}

	public List query(Executor executor) {
		List rows = null;
		if (logger.isDebugEnabled()) {
			logger.debug("executor:" + executor);
		}
		Map params = executor.getParams();
		if (params != null && params.size() > 0) {
			rows = getSqlMapClientTemplate().queryForList(executor.getQuery(),
					params);
		} else {
			List list = executor.getListValues();
			if (list != null && list.size() > 0) {
				rows = getSqlMapClientTemplate().queryForList(
						executor.getQuery(), list.get(0));
			} else {
				rows = getSqlMapClientTemplate().queryForList(
						executor.getQuery(), null);
			}
		}
		return rows;
	}

	/**
	 * ��ȡĳҳ�ļ�¼
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param executor
	 * @return
	 */

	public List getRows(int pageNo, int pageSize, Executor executor) {
		List rows = null;
		if (logger.isDebugEnabled()) {
			logger.debug("executor:" + executor);
		}
		int begin = (pageNo - 1) * pageSize + 1;
		Map params = executor.getParams();
		if (params != null && params.size() > 0) {
			rows = getSqlMapClientTemplate().queryForList(executor.getQuery(),
					params, begin, pageSize);
		} else {
			List list = executor.getListValues();
			if (list != null && list.size() > 0) {
				rows = getSqlMapClientTemplate().queryForList(
						executor.getQuery(), list.get(0), begin, pageSize);
			} else {
				rows = getSqlMapClientTemplate().queryForList(
						executor.getQuery(), null, begin, pageSize);
			}
		}
		return rows;
	}

	/**
	 * ��ҳ��ѯ
	 * 
	 * @param currPageNo
	 * @param pageSize
	 * @param countExecutor
	 * @param queryExecutor
	 * @return
	 */
	public Page getPage(final int pageNo, final int pSize,
			final Executor countExecutor, final Executor queryExecutor) {
		return (Page) getSqlMapClientTemplate().execute(
				new SqlMapClientCallback() {
					public Object doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						if (logger.isDebugEnabled()) {
							logger.debug("count executor:" + countExecutor);
							logger.debug("query executor:" + queryExecutor);
						}
						Page page = new Page();
						int currPageNo = pageNo;
						int pageSize = pSize;
						if (pageSize <= 0) {
							pageSize = Page.DEFAULT_PAGE_SIZE;
						}
						if (currPageNo <= 0) {
							currPageNo = 1;
						}

						Map params = countExecutor.getParams();

						Object obj = null;
						int totalCount = 0;

						if (params != null && params.size() > 0) {
							obj = executor.queryForObject(countExecutor
									.getQuery(), params);
						} else {
							List list = countExecutor.getListValues();
							if (list != null && list.size() > 0) {
								obj = executor.queryForObject(countExecutor
										.getQuery(), list.get(0));
							} else {
								obj = executor.queryForObject(countExecutor
										.getQuery(), null);
							}
						}

						if (obj instanceof Integer) {
							Integer iCount = (Integer) obj;
							totalCount = iCount.intValue();
						} else if (obj instanceof Long) {
							Long iCount = (Long) obj;
							totalCount = iCount.intValue();
						} else if (obj instanceof BigDecimal) {
							BigDecimal bg = (BigDecimal) obj;
							totalCount = bg.intValue();
						} else if (obj instanceof BigInteger) {
							BigInteger bi = (BigInteger) obj;
							totalCount = bi.intValue();
						}

						if (totalCount == 0) {
							page.setRows(new ArrayList());
							page.setCurrentPage(0);
							page.setPageSize(0);
							page.setTotalRecordCount(0);
							return page;
						}

						page.setTotalRecordCount(totalCount);

						int maxPageNo = (page.getTotalRecordCount() + (pageSize - 1))
								/ pageSize;
						if (currPageNo > maxPageNo) {
							currPageNo = maxPageNo;
						}

						List rows = null;

						Map queryParams = queryExecutor.getParams();

						int begin = (pageNo - 1) * pageSize + 1;
						if (queryParams != null && queryParams.size() > 0) {
							rows = getSqlMapClientTemplate().queryForList(
									queryExecutor.getQuery(), queryParams,
									begin, pageSize);
						} else {
							List list = queryExecutor.getListValues();
							if (list != null && list.size() > 0) {
								rows = getSqlMapClientTemplate().queryForList(
										queryExecutor.getQuery(), list.get(0),
										begin, pageSize);
							} else {
								rows = getSqlMapClientTemplate().queryForList(
										queryExecutor.getQuery(), null, begin,
										pageSize);
							}
						}

						page.setRows(rows);
						page.setPageSize(pageSize);
						page.setCurrentPage(currPageNo);

						if (logger.isDebugEnabled()) {
							logger.debug("statement name :"
									+ queryExecutor.getQuery());
							if (params != null) {
								logger.debug("params:" + params);
							}
							logger.debug("rows size:" + rows.size());
						}

						return page;
					}
				});

	}

}
