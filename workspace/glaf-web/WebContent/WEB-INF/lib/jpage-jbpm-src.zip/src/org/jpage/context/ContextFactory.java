/*
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jpage.context;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jpage.core.security.CryptorFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public final class ContextFactory {

	private static Log logger = LogFactory.getLog(ContextFactory.class);

	private static org.springframework.context.ApplicationContext ctx;

	private static org.jpage.core.security.Cryptor cryptor;

	private static DataSource dataSource;

	static {
		logger.info("load spring config......");
		ctx = new ClassPathXmlApplicationContext(
				"classpath*:config/jbpm/jpage-context.xml");
	}

	protected static void init() {
		logger.info("load spring config......");
		if (ctx == null) {
			ctx = new ClassPathXmlApplicationContext(
					"classpath*:config/jbpm/jpage-context.xml");
		}
	}

	protected static void setContext(
			org.springframework.context.ApplicationContext context) {
		ctx = context;
	}

	public static Object getBean(String name) {
		if (ctx == null) {
			org.jpage.context.ContextFactory.init();
		}
		return ctx.getBean(name);
	}

	public static org.jpage.core.security.Cryptor getCryptor() {
		if (cryptor == null) {
			cryptor = (org.jpage.core.security.Cryptor) ContextFactory
					.getBean("cryptor");
		}
		if (cryptor == null) {
			cryptor = CryptorFactory.getCryptor();
		}
		return cryptor;
	}

	public static DataSource getDataSource() {
		if (dataSource == null) {
			dataSource = (DataSource) ContextFactory.getBean("dataSource");
		}
		return dataSource;
	}

	public static DataSource getDataSource(String dataSourceName) {
		return (DataSource) ContextFactory.getBean(dataSourceName);
	}

	public static java.sql.Connection getConnection() throws SQLException {
		if (dataSource == null) {
			dataSource = (DataSource) ContextFactory.getBean("dataSource");
		}
		if (dataSource != null) {
			return dataSource.getConnection();
		}
		return null;
	}

}