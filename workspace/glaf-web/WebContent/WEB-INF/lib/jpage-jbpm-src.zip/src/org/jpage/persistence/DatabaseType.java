/*
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jpage.persistence;

public final class DatabaseType {
	public final static int DB2390_TYPE = 100;

	public final static int DB2400_TYPE = 200;

	public final static int DB2_TYPE = 300;

	public final static int DERBY_TYPE = 400;

	public final static int FIREBIRD_TYPE = 500;

	public final static int FRONTBASE_TYPE = 600;

	public final static int HSQL_TYPE = 700;

	public final static int INFORMIX_TYPE = 800;

	public final static int INGRES_TYPE = 900;

	public final static int INTERBASE_TYPE = 1000;

	public final static int JDATASTORE_TYPE = 1100;

	public final static int MCKOI_TYPE = 1200;

	public final static int MIMERSQL_TYPE = 1300;

	public final static int MYSQL5_TYPE = 1500;

	public final static int MYSQL5INNODB_TYPE = 1501;

	public final static int MYSQL_TYPE = 1502;

	public final static int MYSQLINNODB_TYPE = 1503;

	public final static int ORACLE_TYPE = 1600;

	public final static int ORACLE9I_TYPE = 1601;

	public final static int ORACLE10G_TYPE = 1602;

	public final static int POINTBASE_TYPE = 1700;

	public final static int POSTGRESQL_TYPE = 1800;

	public final static int PROGRESS_TYPE = 1900;

	public final static int SQLSERVER_TYPE = 2000;

	public final static int SAPDB_TYPE = 2100;

	public final static int SYBASE_TYPE = 2200;

	public final static int SYBASEANYWHERE_TYPE = 2201;

	public final static int SYBASE11_TYPE = 2202;

	public final static int TIMESTEN_TYPE = 2300;

	private static int databaseType = 0;

	public static int getDatabaseType() {
		return databaseType;
	}

}
