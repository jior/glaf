package com.glaf.base.res;

import javax.servlet.http.HttpServletRequest;

public class MessageUtils {

	public static void addMessages(HttpServletRequest request, ViewMessages messages){
		
	}
}
