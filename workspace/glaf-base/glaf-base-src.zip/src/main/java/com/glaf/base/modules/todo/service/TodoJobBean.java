/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.glaf.base.modules.todo.service;

import java.util.*;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jbpm.JbpmConfiguration;
import org.jbpm.JbpmContext;
import com.glaf.jbpm.context.Context;
import com.glaf.jbpm.model.TaskItem;
import com.glaf.jbpm.container.ProcessContainer;

import com.glaf.base.modules.others.service.WorkCalendarService;
import com.glaf.base.modules.sys.model.SysDepartment;
import com.glaf.base.modules.sys.model.SysUser;
import com.glaf.base.modules.sys.service.SysUserService;
import com.glaf.core.todo.Todo;
import com.glaf.core.todo.TodoInstance;
import com.glaf.base.utils.DateTools;

public class TodoJobBean {
	private final static Log logger = LogFactory.getLog(TodoJobBean.class);

	private TodoService todoService;

	private WorkCalendarService workCalendarService;

	private SysUserService sysUserService;

	public TodoJobBean() {

	}

	public void create(Todo todo) {
		todoService.create(todo);
	}

	public void createTasks(List processInstanceIds) {
		List tasks = this.getJbpmTasksByProcessInstanceIds(processInstanceIds);
		todoService.createTasks(processInstanceIds, tasks);
		logger.info("���� " + processInstanceIds + " �������Ѿ�����,����������:"
				+ tasks.size());
	}

	public void createTasks(Long processInstanceId) {
		List tasks = this.getJbpmTasksByProcessInstanceId(processInstanceId);
		// todoService.createTasks(processInstanceId, tasks);
		logger.info("���� " + processInstanceId + " �������Ѿ�����,����������:"
				+ tasks.size());
	}

	public void createTasksFromSQL() {
		List rows = this.getTasks();
		todoService.createTasksOfSQL(rows);
	}

	public void createTasksFromWorkflow() {
		List tasks = this.getAllJbpmTasks();
		todoService.createTasksOfWorkflow(tasks);
	}

	public void createTasksFromWorkflow(String actorId) {
		List tasks = this.getJbpmTasks(actorId);
		todoService.createTasksOfWorkflow(actorId, tasks);
	}

	public void createTodoInstances(long todoId) {
		Todo todo = todoService.getTodo(todoId);
		Map rowsMap = new HashMap();
		JbpmContext jbpmContext = null;
		try {
			jbpmContext = ProcessContainer.getContainer().createJbpmContext();
			java.sql.Connection con = jbpmContext.getConnection();
			java.sql.PreparedStatement psmt = con.prepareStatement(todo
					.getSql());
			java.sql.ResultSet rs = psmt.executeQuery();
			java.sql.ResultSetMetaData rsmd = rs.getMetaData();
			while (rs.next()) {
				TodoInstance model = new TodoInstance();
				model.setRowId(rs.getString(1));
				model.setStartDate(rs.getDate(2));
				if (rsmd.getColumnCount() == 3) {
					switch (new Long(todo.getId()).intValue()) {
					case 8005:// ��δ�ú�ͬ��Ч�գ�
					case 7001:
					case 7002:
					case 7003:
					case 7004:
					case 17001:// �ɹ������������
					case 17010:
					case 18001:
					case 19001:
					case 20001:
					case 20084001:// �ʲ���������ȷ��
						model.setDeptId(rs.getLong(3));
						break;
					default:
						model.setActorId(rs.getString(3));
						break;
					}
				}
				rowsMap.put(model.getRowId(), model);
			}
			rs.close();
			psmt.close();
			rs = null;
			psmt = null;
		} catch (java.sql.SQLException ex) {
			ex.printStackTrace();
		} finally {
			Context.close(jbpmContext);
		}

		List rows = new ArrayList();

		if (rowsMap.size() > 0) {
			Iterator iter = rowsMap.keySet().iterator();
			while (iter.hasNext()) {
				String rowId = (String) iter.next();
				TodoInstance model = (TodoInstance) rowsMap.get(rowId);
				Date startDate = model.getStartDate();
				if (startDate == null) {
					startDate = new java.util.Date();
				}

				model.setProvider("sql");
				model.setLinkType(todo.getLinkType());
				model.setAppId(todo.getAppId());
				model.setModuleId(todo.getModuleId());
				model.setTodoId(todo.getId());
				model.setRoleId(todo.getRoleId());
				model.setRoleCode(todo.getRoleCode());
				model.setTitle(todo.getTitle());
				model.setCreateDate(new Date(System.currentTimeMillis()));
				model.setStartDate(startDate);
				int limitDay = todo.getLimitDay();
				int ahour = todo.getXa();
				int bhour = todo.getXb();

				Date limitWorkDate = workCalendarService.getWorkDate(startDate,
						limitDay);
				long time = limitWorkDate.getTime();

				Date cautionDate = new Date(time - ahour * DateTools.HOUR);
				Date pastDueDate = new Date(time + bhour * DateTools.HOUR);
				model.setAlarmDate(cautionDate);
				model.setPastDueDate(pastDueDate);
				model.setRowId(rowId);
				model.setVersionNo(System.currentTimeMillis());
				rows.add(model);
			}
		}

		todoService.createTodoInstances(todoId, rows);

	}

	public void execute() {
		this.createTasksFromWorkflow();
	}

	public List getAllJbpmTasks() {
		List rows = new ArrayList();
		List taskItems = ProcessContainer.getContainer().getAllTaskItems();
		if (taskItems != null && taskItems.size() > 0) {
			logger.info("---------->taskItems size:" + taskItems.size());
			rows = this.getTodoInstances(taskItems);
		}
		return rows;
	}

	public List getAllTodoList() {
		return todoService.getAllTodoList();
	}

	public Collection getAllUsers() {
		SysUserService sysUserService = this.getSysUserService();
		Collection users = sysUserService.getSysUserList();
		return users;
	}

	public Collection getAppActorIds(String appId) {
		Collection actorIds = new HashSet();
		String sql = " select a.account, a.name, c.appId from sys_user a inner join sys_user_role b on a.id = b.userId inner join sys_access c on b.roleId = c.roleId where c.appId = ? ";
		JbpmContext jbpmContext = null;
		try {
			JbpmConfiguration cfg = JbpmConfiguration.getInstance();
			jbpmContext = cfg.createJbpmContext();
			java.sql.Connection con = jbpmContext.getConnection();
			java.sql.PreparedStatement psmt = con.prepareStatement(sql);
			psmt.setString(1, appId);
			java.sql.ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				actorIds.add(rs.getString(1));
			}
			rs.close();
			psmt.close();
			rs = null;
			psmt = null;
		} catch (java.sql.SQLException ex) {
			ex.printStackTrace();
		} finally {
			Context.close(jbpmContext);
		}
		return actorIds;
	}

	public Map getDepartmentMap() {
		return todoService.getDepartmentMap();
	}

	public Map getEnabledTodoMap() {
		return todoService.getEnabledTodoMap();
	}

	public List getJbpmTasks(String actorId) {
		List rows = new ArrayList();
		List taskItems = ProcessContainer.getContainer().getTaskItems(actorId);
		if (taskItems != null && taskItems.size() > 0) {
			rows = this.getTodoInstances(taskItems);
		}
		return rows;
	}

	public List getJbpmTasksByProcessInstanceId(Long processInstanceId) {
		List rows = new ArrayList();
		List taskItems = ProcessContainer.getContainer()
				.getTaskItemsByProcessInstanceId(processInstanceId);
		if (taskItems != null && taskItems.size() > 0) {
			rows = this.getTodoInstances(taskItems);
		}
		return rows;
	}

	public List getJbpmTasksByProcessInstanceIds(List processInstanceIds) {
		List rows = new ArrayList();
		List taskItems = ProcessContainer.getContainer()
				.getTaskItemsByProcessInstanceIds(processInstanceIds);
		if (taskItems != null && taskItems.size() > 0) {
			rows = this.getTodoInstances(taskItems);
		}
		return rows;
	}

	public SysDepartment getParentDepartment(long id) {
		return todoService.getParentDepartment(id);
	}

	public Map getRoleMap() {
		return todoService.getRoleMap();
	}

	public SysUserService getSysUserService() {
		return sysUserService;
	}

	public List getTasks() {
		List todos = todoService.getSQLTodos();
		List rows = new ArrayList();
		if (todos != null && todos.size() > 0) {
			Iterator iterator = todos.iterator();
			while (iterator.hasNext()) {
				Todo todo = (Todo) iterator.next();
				if (StringUtils.isNotEmpty(todo.getSql())) {
					logger.info(todo.getId() + ":" + todo.getSql());
					Map rowsMap = new HashMap();
					JbpmContext jbpmContext = null;
					try {
						JbpmConfiguration cfg = JbpmConfiguration.getInstance();
						jbpmContext = cfg.createJbpmContext();
						java.sql.Connection con = jbpmContext.getConnection();
						java.sql.PreparedStatement psmt = con
								.prepareStatement(todo.getSql());
						java.sql.ResultSet rs = psmt.executeQuery();
						java.sql.ResultSetMetaData rsmd = rs.getMetaData();
						while (rs.next()) {
							TodoInstance model = new TodoInstance();
							model.setRowId(rs.getString(1));
							model.setStartDate(rs.getDate(2));
							if (rsmd.getColumnCount() == 3) {
								switch (new Long(todo.getId()).intValue()) {
								case 8005:// ��δ�ú�ͬ��Ч�գ�
								case 7001:
								case 7002:
								case 7003:
								case 7004:
								case 17001:// �ɹ������������
								case 17010:
								case 18001:
								case 19001:
								case 20001:
								case 20084001:// �ʲ���������ȷ��
									model.setDeptId(rs.getLong(3));
									break;
								default:
									model.setActorId(rs.getString(3));
									break;
								}
							}
							rowsMap.put(model.getRowId(), model);
						}
						rs.close();
						psmt.close();
						rs = null;
						psmt = null;

					} catch (java.sql.SQLException ex) {
						logger.debug(todo.getId() + ":" + todo.getSql());
						ex.printStackTrace();
					} finally {
						Context.close(jbpmContext);
					}

					if (rowsMap.size() > 0) {
						Iterator iter = rowsMap.keySet().iterator();
						while (iter.hasNext()) {
							String rowId = (String) iter.next();
							TodoInstance model = (TodoInstance) rowsMap
									.get(rowId);
							Date startDate = model.getStartDate();
							if (startDate == null) {
								startDate = new java.util.Date();
							}

							model.setProvider("sql");
							model.setLinkType(todo.getLinkType());
							model.setAppId(todo.getAppId());
							model.setModuleId(todo.getModuleId());
							model.setTodoId(todo.getId());
							model.setRoleId(todo.getRoleId());
							model.setRoleCode(todo.getRoleCode());
							model.setTitle(todo.getTitle());
							model.setCreateDate(new Date(System
									.currentTimeMillis()));
							model.setStartDate(startDate);
							int limitDay = todo.getLimitDay();
							int ahour = todo.getXa();
							int bhour = todo.getXb();

							Date limitWorkDate = workCalendarService
									.getWorkDate(startDate, limitDay);
							long time = limitWorkDate.getTime();

							Date cautionDate = new Date(time - ahour
									* DateTools.HOUR);
							Date pastDueDate = new Date(time + bhour
									* DateTools.HOUR);
							model.setAlarmDate(cautionDate);
							model.setPastDueDate(pastDueDate);
							model.setRowId(rowId);
							model.setVersionNo(System.currentTimeMillis());
							rows.add(model);
						}
					}
				}
			}

		}
		return rows;
	}

	public Todo getTodo(long todoId) {
		return todoService.getTodo(todoId);
	}

	public List getTodoInstanceList(Map paramMap) {
		return todoService.getTodoInstanceList(paramMap);
	}

	public List getTodoInstances(List taskItems) {
		List rows = new ArrayList();
		if (taskItems != null && taskItems.size() > 0) {
			logger.info("---------->taskItems size:" + taskItems.size());
			Map userMap = this.getUserMap();
			Map todoMap = this.getTodoMap();

			Iterator iterator = taskItems.iterator();
			while (iterator.hasNext()) {
				TaskItem taskItem = (TaskItem) iterator.next();

				SysUser user = (SysUser) userMap.get(taskItem.getActorId());
				if (user == null) {
					continue;
				}

				Todo todo = null;

				String key001 = taskItem.getProcessName() + "_"
						+ taskItem.getTaskName();
				String key = taskItem.getProcessName() + "_"
						+ taskItem.getTaskName() + "_"
						+ user.getDepartment().getId();

				todo = (Todo) todoMap.get(key);

				if (todo == null) {
					todo = (Todo) todoMap.get(key001);
				}

				if (todo == null) {
					logger.info(key001 + " no todo config .................");
				}

				if (todo != null) {

					TodoInstance model = new TodoInstance();
					model.setProvider("jbpm");
					model.setLinkType(todo.getLinkType());
					model.setAppId(todo.getAppId());
					model.setModuleId(todo.getModuleId());
					model.setTodoId(todo.getId());
					model.setRoleId(todo.getRoleId());
					model.setRoleCode(todo.getRoleCode());
					model.setTitle(todo.getTitle());
					model.setActorId(taskItem.getActorId());
					model.setActorName(user.getName());
					model.setDeptId(user.getDepartment().getId());
					model.setDeptName(user.getDepartment().getName());
					model.setCreateDate(new Date(System.currentTimeMillis()));
					model.setStartDate(taskItem.getCreateDate());
					int limitDay = todo.getLimitDay();
					int ahour = todo.getXa();
					int bhour = todo.getXb();

					Date limitWorkDate = workCalendarService.getWorkDate2(
							model.getStartDate(), limitDay);
					long time = limitWorkDate.getTime();

					Date cautionDate = new Date(time - ahour * DateTools.HOUR);
					Date pastDueDate = new Date(time + bhour * DateTools.HOUR);
					model.setAlarmDate(cautionDate);
					model.setPastDueDate(pastDueDate);
					model.setProcessInstanceId(String.valueOf(taskItem
							.getProcessInstanceId()));
					model.setTaskInstanceId(String.valueOf(taskItem
							.getTaskInstanceId()));
					model.setRowId(taskItem.getRowId());
					model.setVersionNo(System.currentTimeMillis());
					String content = todo.getContent();
					if (StringUtils.isNotEmpty(taskItem.getTaskDescription())) {
						content = content + taskItem.getTaskDescription();
						model.setContent(content);
					} else {
						if (StringUtils.isNotEmpty(taskItem.getRowId())) {
							content = content + " ���ݱ�ţ�" + taskItem.getRowId()
									+ "��";
							model.setContent(content);
						}
					}
					rows.add(model);
				}
			}
		}
		return rows;
	}

	public List getTodoInstances(String actorId) {
		SendMessageBean bean = new SendMessageBean();
		bean.setSysUserService(this.getSysUserService());

		bean.setTodoService(todoService);
		return bean.getTodoInstances(actorId);
	}

	public List getTodoList() {
		return todoService.getTodoList();
	}

	public Map getTodoMap() {
		return todoService.getTodoMap();
	}

	public TodoService getTodoService() {
		return todoService;
	}

	public SysUser getUser(String actorId) {
		return todoService.getUser(actorId);
	}

	public Map getUserMap() {
		return todoService.getUserMap();
	}

	public Map getUserRoleMap(String actorId) {
		return todoService.getUserRoleMap(actorId);
	}

	public Map getUserTodoMap(String actorId) {
		return todoService.getUserTodoMap(actorId);
	}

	public WorkCalendarService getWorkCalendarService() {
		return workCalendarService;
	}

	public List getXYTodoInstances(String actorId) {
		SendMessageBean bean = new SendMessageBean();
		bean.setSysUserService(this.getSysUserService());
		bean.setTodoService(todoService);
		return bean.getXYTodoInstances(actorId);
	}

	public void sendMessage() {
		// logger.info("sendMessage");
		// System.out.println("sendMessage");
		if (todoService.isWorkDate(new Date())) {
			// logger.info("ok--------");
			// System.out.println("ok--------");
			this.sendMessageToAllUsers();
		}
	}

	public void sendMessageToAllUsers() {
		if (todoService.isWorkDate(new Date())) {
			List rows = this.getTasks();
			todoService.createTasksOfSQL(rows);
			List tasks = this.getAllJbpmTasks();
			todoService.createTasksOfWorkflow(tasks);
			SysUserService sysUserService = this.getSysUserService();
			Collection users = sysUserService.getSysUserList();
			if (users != null && users.size() > 0) {
				logger.info("########user size:" + users.size());
				Iterator iterator = users.iterator();
				while (iterator.hasNext()) {
					SysUser user = (SysUser) iterator.next();
					if (user.getBlocked() == 0) {
						try {
							this.sendMessageToUser(user.getAccount());
						} catch (Exception ex) {
							logger.error(ex);
						}
					}
				}
			}
		}
	}

	public void sendMessageToUser(String actorId) {
		SendMessageBean bean = new SendMessageBean();
		bean.setSysUserService(this.getSysUserService());
		bean.setTodoService(todoService);
		bean.sendMessageToUser(actorId);
	}

	public void setSysUserService(SysUserService sysUserService) {
		this.sysUserService = sysUserService;
	}

	public void setTodoService(TodoService todoService) {
		this.todoService = todoService;
	}

	public void setWorkCalendarService(WorkCalendarService workCalendarService) {
		this.workCalendarService = workCalendarService;
		logger.info("setWorkCalendarService");
	}

	public void update(Todo todo) {
		todoService.update(todo);
	}
}