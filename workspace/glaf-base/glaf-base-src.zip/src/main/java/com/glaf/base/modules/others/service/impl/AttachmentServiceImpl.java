/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

package com.glaf.base.modules.others.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.glaf.base.dao.AbstractSpringDao;
import com.glaf.base.modules.Constants;
import com.glaf.base.modules.others.model.Attachment;
import com.glaf.base.modules.others.service.AttachmentService;

public class AttachmentServiceImpl implements AttachmentService {
	private static final Log logger = LogFactory.getLog(AttachmentServiceImpl.class);

	private AbstractSpringDao abstractDao;

	public void setAbstractDao(AbstractSpringDao abstractDao) {
		this.abstractDao = abstractDao;
		logger.info("setAbstractDao");
	}

	/**
	 * ����
	 * 
	 * @param bean
	 *            Attachment
	 * @return boolean
	 */
	public boolean create(Attachment bean) {
		return abstractDao.create(bean);
	}

	/**
	 * ����
	 * 
	 * @param bean
	 *            Attachment
	 * @return boolean
	 */
	public boolean update(Attachment bean) {
		return abstractDao.update(bean);
	}

	/**
	 * ɾ��
	 * 
	 * @param bean
	 *            Attachment
	 * @return boolean
	 */
	public boolean delete(Attachment bean) {
		return abstractDao.delete(bean);
	}

	/**
	 * ɾ��
	 * 
	 * @param id
	 *            int
	 * @return boolean
	 */
	public boolean delete(long id) {
		Attachment bean = find(id);
		if (bean != null) {
			return delete(bean);
		} else {
			return false;
		}
	}

	/**
	 * ����ɾ��
	 * 
	 * @param id
	 * @return
	 */
	public boolean deleteAll(long[] id) {
		String path = Constants.ROOT_PATH + Constants.UPLOAD_DIR;
		logger.info(path);

		List list = new ArrayList();
		for (int i = 0; i < id.length; i++) {
			Attachment bean = find(id[i]);
			// ��ɾ������
			if (bean != null) {
				File file = new File(path + File.separator + bean.getUrl());
				if (file.isFile())
					file.delete();
				list.add(bean);
			}
		}
		return abstractDao.deleteAll(list);
	}

	/**
	 * ��ȡ����
	 * 
	 * @param id
	 * @return
	 */
	public Attachment find(long id) {
		return (Attachment) abstractDao.find(Attachment.class, new Long(id));
	}

	/**
	 * �������и����б�
	 * 
	 * @param parent
	 * @return
	 */
	public List getAttachmentList(long referId, int referType) {
		Object[] values = new Object[] { new Long(referId),
				new Integer(referType) };
		String query = "from Attachment a where a.referId=? and a.referType=? order by a.id desc";
		return abstractDao.getList(query, values, null);
	}

	/**
	 * ���ظ���
	 * 
	 * @param referId
	 * @param referType
	 * @return Attachment
	 */
	public Attachment find(long referId, int referType) {
		Attachment bean = null;
		Object[] values = new Object[] { new Long(referId),
				new Integer(referType) };
		String query = "from Attachment a where a.referId=? and a.referType=? order by a.id desc";
		List list = abstractDao.getList(query, values, null);
		if (list != null && list.size() > 0) {// �м�¼
			bean = (Attachment) list.get(0);
		}
		return bean;
	}

	/**
	 * ���ظ���
	 * 
	 * @param referId
	 * @param referType
	 * @return Attachment
	 */
	public Attachment find(long id, long referId, int referType) {
		Attachment bean = null;
		Object[] values = new Object[] { new Long(id), new Long(referId),
				new Integer(referType) };
		String query = "from Attachment a where a.id=? and a.referId=? and a.referType=? order by a.id desc";
		List list = abstractDao.getList(query, values, null);
		if (list != null && list.size() > 0) {// �м�¼
			bean = (Attachment) list.get(0);
		}
		return bean;
	}

	/**
	 * ���ظ���
	 * 
	 * @param referId
	 * @param referType
	 * @param name
	 * @return Attachment
	 */
	public Attachment find(long referId, int referType, String name) {
		Attachment bean = null;
		Object[] values = new Object[] { new Long(referId),
				new Integer(referType), new String(name) };
		String query = "from Attachment a where a.referId=? and a.referType=? and a.name=? order by a.id desc";
		List list = abstractDao.getList(query, values, null);
		if (list != null && list.size() > 0) {// �м�¼
			bean = (Attachment) list.get(0);
		}
		return bean;
	}

	/**
	 * �������и��������б�
	 * 
	 * @param parent
	 * @return
	 */
	public Map getNameMap(long referId, int referType) {
		List list = getAttachmentList(referId, referType);
		Map map = new HashMap();
		for (int i = 0; list != null && i < list.size(); i++) {
			Attachment atta = (Attachment) list.get(i);
			map.put(atta.getName(), atta.getName());
		}
		return map;
	}

	/**
	 * �������и����б�
	 * 
	 * @param referId
	 * @param referType
	 * @return
	 */
	public List getAttachmentList(long[] referIds, int referType) {
		StringBuffer referId = new StringBuffer("");
		for (int i = 0; i < referIds.length; i++) {
			referId.append(referIds[i]);
			if (i != referIds.length - 1) {
				referId.append(",");
			}
		}
		if (referId.length() == 0) {//
			return new ArrayList();
		}

		String query = "from Attachment a where a.referId IN ("
				+ referId.toString() + ")" + " and a.referType=" + referType
				+ " order by a.referId asc, a.id asc";
		List list = abstractDao.getList(query, null, null);
		if (list == null) {
			list = new ArrayList();
		}
		return list;
	}

	/**
	 * ���ظ�������
	 * 
	 * @param referId
	 * @param referType
	 * @return
	 */
	public int getAttachmentCount(long[] referIds, int referType) {
		StringBuffer referId = new StringBuffer("");
		for (int i = 0; i < referIds.length; i++) {
			referId.append(referIds[i]);
			if (i != referIds.length - 1) {
				referId.append(",");
			}
		}
		if (referId.length() == 0) {//
			return 0;
		}

		String query = "select count(*) from Attachment a where a.referId IN ("
				+ referId.toString() + ")" + " and a.referType=" + referType;
		List list = abstractDao.getList(query, null, null);
		return ((Long) list.iterator().next()).intValue();
	}
	
	/**
	 * ���ض�Ӧ�ĸ����б�
	 * 
	 * @param parent
	 * @return
	 */
	public List getPurchaseAttachmentList(long[] ids, int referType) {
		StringBuffer referId = new StringBuffer("");
		for(int i=0;i<ids.length;i++){
			if(i!=0){
				referId.append(",");
			}
			referId.append(ids[i]);
		}
		if(referId.toString() != null && !"".equals(referId.toString())){
			String query = "from Attachment a where a.id in("+referId.toString()+") and a.referType="+referType+" order by a.id";
			return abstractDao.getList(query, null, null);
		}
		return null;		
	}
}