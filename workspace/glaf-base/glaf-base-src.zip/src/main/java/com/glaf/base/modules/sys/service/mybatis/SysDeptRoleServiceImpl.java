/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.glaf.base.modules.sys.service.mybatis;

import java.util.*;

import javax.annotation.Resource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glaf.core.id.*;
import com.glaf.core.util.PageResult;
import com.glaf.core.dao.*;

import com.glaf.base.modules.sys.SysConstants;
import com.glaf.base.modules.sys.mapper.*;
import com.glaf.base.modules.sys.model.*;
import com.glaf.base.modules.sys.query.*;
import com.glaf.base.modules.sys.service.*;

@Service("sysDeptRoleService")
@Transactional(readOnly = true)
public class SysDeptRoleServiceImpl implements SysDeptRoleService {
	protected final static Log logger = LogFactory
			.getLog(SysDeptRoleServiceImpl.class);

	protected LongIdGenerator idGenerator;

	protected PersistenceDAO persistenceDAO;

	protected SqlSessionTemplate sqlSessionTemplate;

	protected SysDeptRoleMapper sysDeptRoleMapper;

	protected SysUserRoleMapper sysUserRoleMapper;

	protected SysUserMapper sysUserMapper;

	protected SysPermissionMapper sysPermissionMapper;

	protected SysAccessMapper sysAccessMapper;

	protected SysApplicationService sysApplicationService;

	protected SysFunctionService sysFunctionService;

	protected SysRoleService sysRoleService;

	public SysDeptRoleServiceImpl() {

	}

	@Transactional
	public void deleteById(Long id) {
		if (id != null) {
			sysDeptRoleMapper.deleteSysDeptRoleById(id);
		}
	}

	@Transactional
	public void deleteByIds(List<Long> rowIds) {
		if (rowIds != null && !rowIds.isEmpty()) {
			SysDeptRoleQuery query = new SysDeptRoleQuery();
			query.rowIds(rowIds);
			sysDeptRoleMapper.deleteSysDeptRoles(query);
		}
	}

	public int count(SysDeptRoleQuery query) {
		query.ensureInitialized();
		return sysDeptRoleMapper.getSysDeptRoleCount(query);
	}

	public List<SysDeptRole> list(SysDeptRoleQuery query) {
		query.ensureInitialized();
		List<SysDeptRole> list = sysDeptRoleMapper.getSysDeptRoles(query);
		return list;
	}

	public int getSysDeptRoleCountByQueryCriteria(SysDeptRoleQuery query) {
		return sysDeptRoleMapper.getSysDeptRoleCount(query);
	}

	public List<SysDeptRole> getSysDeptRolesByQueryCriteria(int start,
			int pageSize, SysDeptRoleQuery query) {
		RowBounds rowBounds = new RowBounds(start, pageSize);
		List<SysDeptRole> rows = sqlSessionTemplate.selectList(
				"getSysDeptRoles", query, rowBounds);
		return rows;
	}

	public SysDeptRole getSysDeptRole(Long id) {
		if (id == null) {
			return null;
		}
		SysDeptRole sysDeptRole = sysDeptRoleMapper.getSysDeptRoleById(id);
		return sysDeptRole;
	}

	@Transactional
	public void save(SysDeptRole sysDeptRole) {
		if (sysDeptRole.getId() == 0L) {
			sysDeptRole.setId(idGenerator.getNextId());
			// sysDeptRole.setCreateDate(new Date());
			sysDeptRoleMapper.insertSysDeptRole(sysDeptRole);
		} else {
			sysDeptRoleMapper.updateSysDeptRole(sysDeptRole);
		}
	}

	@Resource
	@Qualifier("myBatisDbLongIdGenerator")
	public void setLongIdGenerator(LongIdGenerator idGenerator) {
		this.idGenerator = idGenerator;
	}

	@Resource
	public void setSysDeptRoleMapper(SysDeptRoleMapper sysDeptRoleMapper) {
		this.sysDeptRoleMapper = sysDeptRoleMapper;
	}

	@Resource
	public void setPersistenceDAO(PersistenceDAO persistenceDAO) {
		this.persistenceDAO = persistenceDAO;
	}

	@Resource
	public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
		this.sqlSessionTemplate = sqlSessionTemplate;
	}

	@Resource
	public void setSysApplicationService(
			SysApplicationService sysApplicationService) {
		this.sysApplicationService = sysApplicationService;
	}

	@Resource
	public void setSysFunctionService(SysFunctionService sysFunctionService) {
		this.sysFunctionService = sysFunctionService;
	}

	@Resource
	public void setSysRoleService(SysRoleService sysRoleService) {
		this.sysRoleService = sysRoleService;
	}

	@Resource
	public void setSysUserRoleMapper(SysUserRoleMapper sysUserRoleMapper) {
		this.sysUserRoleMapper = sysUserRoleMapper;
	}

	@Resource
	public void setSysPermissionMapper(SysPermissionMapper sysPermissionMapper) {
		this.sysPermissionMapper = sysPermissionMapper;
	}

	@Resource
	public void setSysAccessMapper(SysAccessMapper sysAccessMapper) {
		this.sysAccessMapper = sysAccessMapper;
	}

	@Resource
	public void setSysUserMapper(SysUserMapper sysUserMapper) {
		this.sysUserMapper = sysUserMapper;
	}

	@Transactional
	public boolean create(SysDeptRole bean) {
		this.save(bean);
		return true;
	}

	@Transactional
	public boolean update(SysDeptRole bean) {
		this.save(bean);
		return true;
	}

	@Transactional
	public boolean delete(SysDeptRole bean) {
		this.deleteById(bean.getId());
		return true;
	}

	@Transactional
	public boolean delete(long id) {
		this.deleteById(id);
		return true;
	}

	@Transactional
	public boolean deleteAll(long[] ids) {
		if (ids != null && ids.length > 0) {
			for (long id : ids) {
				this.deleteById(id);
			}
		}
		return true;
	}
	
	@Transactional
	public boolean deleteByDept(long deptId) {
		sysDeptRoleMapper.deleteSysDeptRoleByDeptId(deptId);
		return true;
	}

	public SysDeptRole findById(long id) {
		return this.getSysDeptRole(id);
	}

	public SysDeptRole find(long deptId, long roleId) {
		SysDeptRoleQuery query = new SysDeptRoleQuery();
		query.setDeptId(deptId);
		query.setSysRoleId(roleId);
		query.setOrderBy(" E.ID desc ");
		List<SysDeptRole> list = this.list(query);
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}

	public Set<SysUser> findRoleUser(long deptId, String roleCode) {
		Set<SysUser> users = new HashSet<SysUser>();
		SysDeptRole deptRole = null;

		SysRole role = sysRoleService.findByCode(roleCode);
		if (role != null) {
			deptRole = find(deptId, role.getId());
		}
		if (deptRole != null) {
			List<SysUser> list = sysUserMapper
					.getSysRoleUsers(deptRole.getId());
			if (list != null && !list.isEmpty()) {
				users.addAll(list);
			}
		}

		return users;
	}

	public PageResult getRoleList(long deptId, int pageNo, int pageSize) {
		// ��������
		PageResult pager = new PageResult();
		SysDeptRoleQuery query = new SysDeptRoleQuery();
		query.deptId(Long.valueOf(deptId));
		int count = this.count(query);
		if (count == 0) {// �����Ϊ��
			pager.setPageSize(pageSize);
			return pager;
		}
		query.setOrderBy(" E.SORT desc");

		int start = pageSize * (pageNo - 1);
		List<SysDeptRole> list = this.getSysDeptRolesByQueryCriteria(start,
				pageSize, query);
		pager.setResults(list);
		pager.setPageSize(pageSize);
		pager.setCurrentPageNo(pageNo);
		pager.setTotalRecordCount(count);

		return pager;
	}

	public List<SysDeptRole> getRoleList(long deptId) {
		SysDeptRoleQuery query = new SysDeptRoleQuery();
		query.setDeptId(deptId);
		return this.list(query);
	}

	/**
	 * ����
	 * 
	 * @param bean
	 *            SysDeptRole
	 * @param operate
	 *            int ����
	 */
	@Transactional
	public void sort(SysDeptRole bean, int operate) {
		if (bean == null)
			return;
		if (operate == SysConstants.SORT_PREVIOUS) {// ǰ��
			sortByPrevious(bean);
		} else if (operate == SysConstants.SORT_FORWARD) {// ����
			sortByForward(bean);
		}
	}

	/**
	 * ��ǰ�ƶ�����
	 * 
	 * @param bean
	 */
	private void sortByPrevious(SysDeptRole bean) {
		SysDeptRoleQuery query = new SysDeptRoleQuery();
		query.setDeptId(bean.getDeptId());
		query.setSortGreaterThan(bean.getSort());
		query.setOrderBy(" E.SORT asc ");
		// ����ǰһ������

		List<SysDeptRole> list = this.list(query);
		if (list != null && list.size() > 0) {// �м�¼
			SysDeptRole temp = (SysDeptRole) list.get(0);
			int i = bean.getSort();
			bean.setSort(temp.getSort());
			this.update(bean);// ����bean

			temp.setSort(i);
			this.update(temp);// ����temp
		}
	}

	/**
	 * ����ƶ�����
	 * 
	 * @param bean
	 */
	private void sortByForward(SysDeptRole bean) {
		SysDeptRoleQuery query = new SysDeptRoleQuery();
		query.setDeptId(bean.getDeptId());
		query.setSortLessThan(bean.getSort());
		query.setOrderBy(" E.SORT desc ");

		// ���Һ�һ������
		List<SysDeptRole> list = this.list(query);
		if (list != null && list.size() > 0) {// �м�¼
			SysDeptRole temp = (SysDeptRole) list.get(0);
			int i = bean.getSort();
			bean.setSort(temp.getSort());
			this.update(bean);// ����bean

			temp.setSort(i);
			this.update(temp);// ����temp
		}
	}

	/**
	 * ���ý�ɫ��Ӧ��ģ�顢����
	 * 
	 * @param roleId
	 * @param appId
	 * @param funcId
	 * @return
	 */
	@Transactional
	public boolean saveRoleApplication(long roleId, long[] appIds,
			long[] funcIds) {
		SysDeptRole role = findById(roleId);
		if (appIds != null) {
			sysAccessMapper.deleteSysAccessByRoleId(roleId);
			// ���ý�ɫ��Ӧ��ģ�����Ȩ��
			for (int i = 0; i < appIds.length; i++) {
				logger.info("app id:" + appIds[i]);
				SysAccess access = new SysAccess();
				access.setAppId(appIds[i]);
				access.setRoleId(role.getId());
				sysAccessMapper.insertSysAccess(access);
			}
		}

		// ����ģ���Ӧ�Ĺ��ܲ���Ȩ��
		if (funcIds != null) {
			sysPermissionMapper.deleteSysPermissionByRoleId(roleId);
			for (int i = 0; i < funcIds.length; i++) {
				logger.info("function id:" + funcIds[i]);
				SysPermission p = new SysPermission();
				p.setFuncId(funcIds[i]);
				p.setRoleId(role.getId());
				sysPermissionMapper.insertSysPermission(p);
			}
		}
		return true;
	}

}
