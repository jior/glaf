/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.glaf.base.modules.sys.service.mybatis;

import java.util.*;

import javax.annotation.Resource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glaf.core.id.*;
import com.glaf.core.dao.*;

import com.glaf.base.modules.sys.SysConstants;
import com.glaf.base.modules.sys.mapper.*;
import com.glaf.base.modules.sys.model.*;
import com.glaf.base.modules.sys.query.*;
import com.glaf.base.modules.sys.service.*;

@Service("sysFunctionService")
@Transactional(readOnly = true)
public class SysFunctionServiceImpl implements SysFunctionService {
	protected final static Log logger = LogFactory
			.getLog(SysFunctionServiceImpl.class);

	protected LongIdGenerator idGenerator;

	protected PersistenceDAO persistenceDAO;

	protected SqlSessionTemplate sqlSessionTemplate;

	protected SysFunctionMapper sysFunctionMapper;

	public SysFunctionServiceImpl() {

	}

	@Transactional
	public void deleteById(Long id) {
		if (id != null) {
			sysFunctionMapper.deleteSysFunctionById(id);
		}
	}

	@Transactional
	public void deleteByIds(List<Long> rowIds) {
		if (rowIds != null && !rowIds.isEmpty()) {
			SysFunctionQuery query = new SysFunctionQuery();
			query.rowIds(rowIds);
			sysFunctionMapper.deleteSysFunctions(query);
		}
	}

	public int count(SysFunctionQuery query) {
		query.ensureInitialized();
		return sysFunctionMapper.getSysFunctionCount(query);
	}

	public List<SysFunction> list(SysFunctionQuery query) {
		query.ensureInitialized();
		List<SysFunction> list = sysFunctionMapper.getSysFunctions(query);
		return list;
	}

	public int getSysFunctionCountByQueryCriteria(SysFunctionQuery query) {
		return sysFunctionMapper.getSysFunctionCount(query);
	}

	public List<SysFunction> getSysFunctionsByQueryCriteria(int start,
			int pageSize, SysFunctionQuery query) {
		RowBounds rowBounds = new RowBounds(start, pageSize);
		List<SysFunction> rows = sqlSessionTemplate.selectList(
				"getSysFunctions", query, rowBounds);
		return rows;
	}

	public SysFunction getSysFunction(Long id) {
		if (id == null) {
			return null;
		}
		SysFunction sysFunction = sysFunctionMapper.getSysFunctionById(id);
		return sysFunction;
	}

	@Transactional
	public void save(SysFunction sysFunction) {
		if (sysFunction.getId() == 0L) {
			sysFunction.setId(idGenerator.getNextId());
			// sysFunction.setCreateDate(new Date());
			sysFunctionMapper.insertSysFunction(sysFunction);
		} else {
			sysFunctionMapper.updateSysFunction(sysFunction);
		}
	}

	@Resource
	@Qualifier("myBatisDbLongIdGenerator")
	public void setLongIdGenerator(LongIdGenerator idGenerator) {
		this.idGenerator = idGenerator;
	}

	@Resource
	public void setSysFunctionMapper(SysFunctionMapper sysFunctionMapper) {
		this.sysFunctionMapper = sysFunctionMapper;
	}

	@Resource
	public void setPersistenceDAO(PersistenceDAO persistenceDAO) {
		this.persistenceDAO = persistenceDAO;
	}

	@Resource
	public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
		this.sqlSessionTemplate = sqlSessionTemplate;
	}

	@Transactional
	public boolean create(SysFunction bean) {
		if (bean.getId() == 0L) {
			bean.setId(idGenerator.getNextId());
		}
		bean.setSort((int) bean.getId());
		sysFunctionMapper.insertSysFunction(bean);
		return true;
	}

	@Transactional
	public boolean update(SysFunction bean) {
		sysFunctionMapper.updateSysFunction(bean);
		return true;
	}

	@Transactional
	public boolean delete(SysFunction bean) {
		this.deleteById(bean.getId());
		return true;
	}

	@Transactional
	public boolean delete(long id) {
		this.deleteById(id);
		return true;
	}

	@Transactional
	public boolean deleteAll(long[] ids) {
		if (ids != null && ids.length > 0) {
			for (long id : ids) {
				this.deleteById(id);
			}
		}
		return true;
	}

	public SysFunction findById(long id) {
		return this.getSysFunction(id);
	}

	public List<SysFunction> getSysFunctionList(int appId) {
		SysFunctionQuery query = new SysFunctionQuery();
		query.appId(Long.valueOf(appId));
		query.setOrderBy(" E.SORT desc ");
		return this.list(query);
	}

	public List<SysFunction> getSysFunctionList() {
		SysFunctionQuery query = new SysFunctionQuery();
		query.setOrderBy(" E.SORT desc ");
		return this.list(query);
	}

	/**
	 * ����
	 * 
	 * @param bean
	 *            SysFunction
	 * @param operate
	 *            int ����
	 */
	@Transactional
	public void sort(SysFunction bean, int operate) {
		if (bean == null)
			return;
		if (operate == SysConstants.SORT_PREVIOUS) {// ǰ��
			sortByPrevious(bean);
		} else if (operate == SysConstants.SORT_FORWARD) {// ����
			sortByForward(bean);
		}
	}

	/**
	 * ��ǰ�ƶ�����
	 * 
	 * @param bean
	 */
	private void sortByPrevious(SysFunction bean) {
		SysFunctionQuery query = new SysFunctionQuery();
		query.appId(Long.valueOf(bean.getAppId()));
		query.setSortGreaterThan(bean.getSort());
		query.setOrderBy(" E.SORT asc ");
		// ����ǰһ������
		List<SysFunction> list = this.list(query);
		if (list != null && list.size() > 0) {// �м�¼
			SysFunction temp = (SysFunction) list.get(0);
			int i = bean.getSort();
			bean.setSort(temp.getSort());
			this.update(bean);// ����bean

			temp.setSort(i);
			this.update(temp);// ����temp
		}
	}

	/**
	 * ����ƶ�����
	 * 
	 * @param bean
	 */
	private void sortByForward(SysFunction bean) {
		SysFunctionQuery query = new SysFunctionQuery();
		query.appId(Long.valueOf(bean.getAppId()));
		query.setSortLessThan(bean.getSort());
		query.setOrderBy(" E.SORT desc ");
		// ����ǰһ������
		List<SysFunction> list = this.list(query);
		if (list != null && list.size() > 0) {// �м�¼
			SysFunction temp = (SysFunction) list.get(0);
			int i = bean.getSort();
			bean.setSort(temp.getSort());
			this.update(bean);// ����bean

			temp.setSort(i);
			this.update(temp);// ����temp
		}
	}
}
