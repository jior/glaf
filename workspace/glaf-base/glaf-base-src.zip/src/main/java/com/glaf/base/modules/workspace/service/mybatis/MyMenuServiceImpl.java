/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.glaf.base.modules.workspace.service.mybatis;

import java.util.*;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glaf.core.id.*;
import com.glaf.core.util.PageResult;
import com.glaf.core.dao.*;

import com.glaf.base.modules.sys.SysConstants;
import com.glaf.base.modules.workspace.mapper.*;
import com.glaf.base.modules.workspace.model.*;
import com.glaf.base.modules.workspace.query.*;
import com.glaf.base.modules.workspace.service.*;

@Service("myMenuService")
@Transactional(readOnly = true)
public class MyMenuServiceImpl implements MyMenuService {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	protected LongIdGenerator idGenerator;

	protected PersistenceDAO persistenceDAO;

	protected SqlSessionTemplate sqlSessionTemplate;

	protected MyMenuMapper myMenuMapper;

	public MyMenuServiceImpl() {

	}

	@Transactional
	public void deleteById(Long id) {
		if (id != null) {
			myMenuMapper.deleteMyMenuById(id);
		}
	}

	@Transactional
	public void deleteByIds(List<Long> rowIds) {
		if (rowIds != null && !rowIds.isEmpty()) {
			MyMenuQuery query = new MyMenuQuery();
			query.rowIds(rowIds);
			myMenuMapper.deleteMyMenus(query);
		}
	}

	public int count(MyMenuQuery query) {
		query.ensureInitialized();
		return myMenuMapper.getMyMenuCount(query);
	}

	public List<MyMenu> list(MyMenuQuery query) {
		query.ensureInitialized();
		List<MyMenu> list = myMenuMapper.getMyMenus(query);
		return list;
	}

	public int getMyMenuCountByQueryCriteria(MyMenuQuery query) {
		return myMenuMapper.getMyMenuCount(query);
	}

	public List<MyMenu> getMyMenusByQueryCriteria(int start, int pageSize,
			MyMenuQuery query) {
		RowBounds rowBounds = new RowBounds(start, pageSize);
		List<MyMenu> rows = sqlSessionTemplate.selectList("getMyMenus", query,
				rowBounds);
		return rows;
	}

	public MyMenu getMyMenu(Long id) {
		if (id == null) {
			return null;
		}
		MyMenu myMenu = myMenuMapper.getMyMenuById(id);
		return myMenu;
	}

	@Transactional
	public void save(MyMenu myMenu) {
		if (myMenu.getId() == 0L) {
			myMenu.setId(idGenerator.getNextId());
			// myMenu.setCreateDate(new Date());
			myMenuMapper.insertMyMenu(myMenu);
		} else {
			myMenuMapper.updateMyMenu(myMenu);
		}
	}

	@Resource
	@Qualifier("myBatisDbLongIdGenerator")
	public void setLongIdGenerator(LongIdGenerator idGenerator) {
		this.idGenerator = idGenerator;
	}

	@Resource
	public void setMyMenuMapper(MyMenuMapper myMenuMapper) {
		this.myMenuMapper = myMenuMapper;
	}

	@Resource
	public void setPersistenceDAO(PersistenceDAO persistenceDAO) {
		this.persistenceDAO = persistenceDAO;
	}

	@Resource
	public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
		this.sqlSessionTemplate = sqlSessionTemplate;
	}

	public boolean create(MyMenu bean) {
		this.save(bean);
		return true;
	}

	public boolean delete(long id) {
		this.deleteById(id);
		return true;
	}

	public boolean delete(MyMenu myMenu) {
		this.deleteById(myMenu.getId());
		return true;
	}

	@SuppressWarnings("rawtypes")
	public boolean deleteAll(Collection c) {
		for (Object object : c) {
			if (object instanceof Long) {
				this.deleteById((Long) object);
			}
			if (object instanceof MyMenu) {
				MyMenu bean = (MyMenu) object;
				this.deleteById(bean.getId());
			}
		}
		return true;
	}

	public MyMenu find(long id) {
		return this.getMyMenu(id);
	}

	public List<MyMenu> getMyMenuList(long userId) {
		MyMenuQuery query = new MyMenuQuery();
		query.setUserId(userId);
		return this.list(query);
	}

	public PageResult getMyMenuList(long userId, int pageNo, int pageSize) {
		// ��������
		PageResult pager = new PageResult();
		MyMenuQuery query = new MyMenuQuery();
		query.userId(userId);

		int count = this.count(query);
		if (count == 0) {// �����Ϊ��
			pager.setPageSize(pageSize);
			return pager;
		}
		query.setOrderBy(" E.ID desc");

		int start = pageSize * (pageNo - 1);
		List<MyMenu> list = this.getMyMenusByQueryCriteria(start, pageSize,
				query);
		pager.setResults(list);
		pager.setPageSize(pageSize);
		pager.setCurrentPageNo(pageNo);
		pager.setTotalRecordCount(count);

		return pager;
	}

	/**
	 * ����
	 * 
	 * @param bean
	 *            MyMenu
	 * @param operate
	 *            int ����
	 */
	public void sort(MyMenu bean, int operate) {
		if (bean == null)
			return;
		if (operate == SysConstants.SORT_PREVIOUS) {// ǰ��
			sortByPrevious(bean);
		} else if (operate == SysConstants.SORT_FORWARD) {// ����
			sortByForward(bean);
		}
	}

	/**
	 * ��ǰ�ƶ�����
	 * 
	 * @param bean
	 */
	private void sortByPrevious(MyMenu bean) {
		MyMenuQuery query = new MyMenuQuery();
		query.setUserId(bean.getUserId());

		// ����ǰһ������
		// String query =
		// "from MyMenu a where a.userId=? and a.sort>? order by a.sort asc";
		List<MyMenu> list = this.list(query);
		if (list != null && list.size() > 0) {// �м�¼
			MyMenu temp = (MyMenu) list.get(0);
			int i = bean.getSort();
			bean.setSort(temp.getSort());
			this.update(bean);// ����bean

			temp.setSort(i);
			this.update(temp);// ����temp

		}
	}

	/**
	 * ����ƶ�����
	 * 
	 * @param bean
	 */
	private void sortByForward(MyMenu bean) {
		MyMenuQuery query = new MyMenuQuery();
		query.setUserId(bean.getUserId());
		// ���Һ�һ������
		// String query =
		// "from MyMenu a where a.userId=? and a.sort<? order by a.sort desc";
		List<MyMenu> list = this.list(query);
		if (list != null && list.size() > 0) {// �м�¼
			MyMenu temp = (MyMenu) list.get(0);
			int i = bean.getSort();
			bean.setSort(temp.getSort());
			this.update(bean);// ����bean

			temp.setSort(i);
			this.update(temp);// ����temp

		}
	}

	public boolean update(MyMenu myMenu) {
		this.save(myMenu);
		return true;
	}

}
