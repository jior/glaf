/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

package com.glaf.base.modules.others.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.springframework.web.struts.DispatchActionSupport;

import com.glaf.base.modules.others.service.AttachmentService;
import com.glaf.base.utils.ParamUtil;

public class AttachmentAction extends DispatchActionSupport {
	private static final Log logger = LogFactory.getLog(AttachmentAction.class);

	private AttachmentService attachmentService;

	public void setAttachmentService(AttachmentService attachmentService) {
		this.attachmentService = attachmentService;
		logger.info("setAttachmentService");
	}

	/**
	 * ��ʾ�����б�
	 * 
	 * @param mapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward showList(ActionMapping mapping, ActionForm actionForm,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		long referId = ParamUtil.getLongParameter(request, "referId", 0);
		int referType = ParamUtil.getIntParameter(request, "referType", 0);
		int viewType = ParamUtil.getIntParameter(request, "viewType", 0);

		request.setAttribute("list",
				attachmentService.getAttachmentList(referId, referType));

		if (viewType == 1) {
			return mapping.findForward("show_list");
		}
		if (viewType == 2) {
			return mapping.findForward("show_add_list");
		} else {
			return mapping.findForward("show_view_list");
		}
	}

	/**
	 * ��ʾ�����б� ��ͬ����������Ӹ���,ֻ���ϴ��߲���ɾ������
	 * 
	 * @param mapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward showList2(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		long referId = ParamUtil.getLongParameter(request, "referId", 0);
		int referType = ParamUtil.getIntParameter(request, "referType", 0);
		int viewType = ParamUtil.getIntParameter(request, "viewType", 0);

		request.setAttribute("list",
				attachmentService.getAttachmentList(referId, referType));

		return mapping.findForward("show_list2");
	}

	/**
	 * �ύɾ��
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward batchDelete(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		boolean ret = true;
		long[] id = ParamUtil.getLongParameterValues(request, "id");
		ret = attachmentService.deleteAll(id);
		ActionMessages messages = new ActionMessages();

		if (ret) {// ����ɹ�
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
					"attach.del_success"));
		} else { // ɾ��ʧ��
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
					"attach.del_failure"));
		}
		addMessages(request, messages);
		return mapping.findForward("show_msg2");
	}

	/**
	 * ��ʾ�����б�
	 * 
	 * @param mapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward showLists(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String referIds = ParamUtil.getParameter(request, "referId");
		int referType = ParamUtil.getIntParameter(request, "referType", 0);
		String[] referIdArray = StringUtils.split(referIds, ",");
		long[] referId = new long[referIdArray.length];
		for (int i = 0; i < referIdArray.length; i++) {
			referId[i] = Long.parseLong(referIdArray[i]);
		}

		request.setAttribute("list",
				attachmentService.getAttachmentList(referId, referType));

		return mapping.findForward("show_view_list");

	}

	/**
	 * ��ʾ��������ҳ��
	 * 
	 * @param mapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward showCount(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String referId = ParamUtil.getParameter(request, "referId");
		int referType = ParamUtil.getIntParameter(request, "referType", 0);
		String[] referIdArray = StringUtils.split(referId, ",");
		long[] longReferId = new long[referIdArray.length];
		for (int i = 0; i < referIdArray.length; i++) {
			longReferId[i] = Long.parseLong(referIdArray[i]);
		}
		int count = attachmentService
				.getAttachmentCount(longReferId, referType);
		String Strcount = count + "";
		request.setAttribute("count", Strcount);
		return mapping.findForward("showCount");
	}
}