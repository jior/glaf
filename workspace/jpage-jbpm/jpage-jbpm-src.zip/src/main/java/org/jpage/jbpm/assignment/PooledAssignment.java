/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/


package org.jpage.jbpm.assignment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jbpm.context.exe.ContextInstance;
import org.jbpm.graph.def.Node;
import org.jbpm.graph.exe.ExecutionContext;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.node.TaskNode;
import org.jbpm.taskmgmt.def.AssignmentHandler;
import org.jbpm.taskmgmt.def.Task;
import org.jbpm.taskmgmt.exe.Assignable;
import org.jpage.actor.Actor;
import org.jpage.actor.User;
import org.jpage.jbpm.config.ObjectFactory;
import org.jpage.jbpm.context.JbpmContextFactory;
import org.jpage.jbpm.service.ActorManager;
import org.jpage.jbpm.util.Constant;

/**
 * �������˵���� �������ȼ�˳����������Ĳ�����<br>
 * 1��ֱ�Ӵ��ⲿ��ȡ�Ķ�̬������ID <br>
 * 2����������Ԥ����Ĳ�����<br>
 * 3������������Swimlane����Ĳ�����<br>
 * 4�����̶����ļ���expression����Ĳ�����
 * 
 */
public class PooledAssignment implements AssignmentHandler {
	private static final Log logger = LogFactory.getLog(PooledAssignment.class);

	private static final long serialVersionUID = 1L;

	private String taskName;

	/**
	 * ��̬���õĲ����ߵĲ�������������������ͨ��contextInstance.getVariable()ȡ��
	 * ���磺contextInstance.getVariable("SendDocAuditor");
	 */
	private String dynamicActors;

	/**
	 * ������ܻ�ȡ����������Ƿ��뿪���ڵ㣨����ڵ㣩
	 */
	private String leaveNodeIfActorNotAvailable;

	private String transitionName;

	private ActorManager actorManager;

	public PooledAssignment() {

	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getDynamicActors() {
		return dynamicActors;
	}

	public void setDynamicActors(String dynamicActors) {
		this.dynamicActors = dynamicActors;
	}

	public String getLeaveNodeIfActorNotAvailable() {
		return leaveNodeIfActorNotAvailable;
	}

	public void setLeaveNodeIfActorNotAvailable(
			String leaveNodeIfActorNotAvailable) {
		this.leaveNodeIfActorNotAvailable = leaveNodeIfActorNotAvailable;
	}

	public String getTransitionName() {
		return transitionName;
	}

	public void setTransitionName(String transitionName) {
		this.transitionName = transitionName;
	}

	public void assign(Assignable assignable, ExecutionContext ctx) {
		logger.debug("-------------------------------------------------------");
		logger.debug("------------------PooledAssignment---------------------");
		logger.debug("-------------------------------------------------------");

		Task task = null;

		actorManager = (ActorManager) JbpmContextFactory
				.getBean("actorManager");

		if (StringUtils.isNotBlank(taskName)) {
			Node node = ctx.getNode();
			if (node instanceof TaskNode) {
				TaskNode taskNode = (TaskNode) node;
				task = taskNode.getTask(taskName);
			}
		}

		if (task == null) {
			task = ctx.getTask();
			taskName = task.getName();
		}

		if (task != null) {
			ContextInstance contextInstance = ctx.getContextInstance();
			List actorIds = new ArrayList();
			if (StringUtils.isNotBlank(dynamicActors)) {
				String actorId = (String) contextInstance
						.getVariable(dynamicActors);
				if (StringUtils.isNotBlank(actorId)) {
					StringTokenizer st2 = new StringTokenizer(actorId, ",");
					while (st2.hasMoreTokens()) {
						String elem = st2.nextToken();
						if (StringUtils.isNotBlank(elem)) {
							actorIds.add(elem);
						}
					}
				}
			}

			ProcessInstance processInstance = contextInstance
					.getProcessInstance();
			String processName = processInstance.getProcessDefinition()
					.getName();

			String roleId = processName + "-" + taskName;
			List actors = actorManager.getActors(ctx.getJbpmContext(), roleId);
			if (actors != null && actors.size() > 0) {
				Iterator iterator = actors.iterator();
				while (iterator.hasNext()) {
					Object obj = iterator.next();
					String actorId = null;
					if (obj instanceof String) {
						actorId = (String) obj;
					} else if (obj instanceof org.jpage.actor.Actor) {
						Actor actor = (Actor) obj;
						actorId = actor.getActorId();
					} else if (obj instanceof org.jpage.actor.User) {
						User user = (User) obj;
						actorId = user.getActorId();
					}
					if (actorId != null) {
						actorIds.add(actorId);
					}
				}
			}

			if (actorIds.size() == 0) {

				if (StringUtils.isNotBlank(leaveNodeIfActorNotAvailable)) {
					if (StringUtils
							.equals("true", leaveNodeIfActorNotAvailable)) {

						contextInstance.setVariable(Constant.IS_AGREE, "true");

						if (StringUtils.isNotBlank(transitionName)) {
							ctx.leaveNode(transitionName);
						} else {
							ctx.leaveNode();
						}
						if (ctx.getNode() != null) {
							logger.debug(ctx.getNode().getName()
									+ "->���ܻ�ȡ��������ߣ��뿪��ǰ�ڵ㡣");
						} else {
							if (ctx.getToken() != null) {
								logger.debug(ctx.getToken().getName()
										+ "->���ܻ�ȡ��������ߣ��뿪��ǰ�ڵ㡣");
							}
						}
						return;
					}
				}

				if (ObjectFactory.isDefaultActorEnable()) {
					String defaultActors = ObjectFactory.getDefaultActors();
					if (StringUtils.isNotBlank(defaultActors)) {
						StringTokenizer st2 = new StringTokenizer(
								defaultActors, ",");
						while (st2.hasMoreTokens()) {
							String elem = st2.nextToken();
							if (StringUtils.isNotBlank(elem)) {
								actorIds.add(elem);
							}
						}
					}
				}
			}

			logger.debug("actorIds size:" + actorIds.size());

			if (actorIds.size() == 1) {
				String actorId = (String) actorIds.get(0);
				assignable.setActorId(actorId);
				logger.debug("actorId:" + actorId);
			} else if (actorIds.size() > 1) {
				int i = 0;
				String[] array = new String[actorIds.size()];
				Iterator iterator = actorIds.iterator();
				while (iterator.hasNext()) {
					String actorId = (String) iterator.next();
					array[i++] = actorId;
					logger.debug("pooed actorId:" + actorId);
				}
				assignable.setPooledActors(array);
			}

		}
	}

}
