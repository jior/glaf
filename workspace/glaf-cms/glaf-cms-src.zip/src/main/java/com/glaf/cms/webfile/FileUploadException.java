package com.glaf.cms.webfile;

public class FileUploadException extends Exception {
	private static final long serialVersionUID = 1L;

	public FileUploadException(String desc) {
		super(desc);
	}
}
