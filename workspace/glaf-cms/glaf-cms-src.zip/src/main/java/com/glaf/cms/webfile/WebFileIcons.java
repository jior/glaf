package com.glaf.cms.webfile;

import java.util.ListResourceBundle;

public class WebFileIcons extends ListResourceBundle {

	private Object contents[][] = { { "", "default.gif" } };

	public WebFileIcons() {
	}

	public Object[][] getContents() {
		return contents;
	}
}
